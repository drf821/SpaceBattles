// File name: SpaceObject

// Written by: Daniel Faubel
 
// Description: SpaceObject has variables and methods that other SpaceObjects are extended from
//              
// Challenges: 
//
// Time Spent: 30 min

// Revision History:
// Date: 11/22/16           30min	By: Daniel Faubel     Action: Created The GUI Interface for StartMenu
// Date: 12/5/16            30min       By Daniel Faubel      Action: Gave SpaceObject a polygon variable and I added 2 get methods 
//                                                                    for the X and Y. Also added a getpolygon method
// Date 12/6/16             60min       By Daniel Faubel      Action: added Sets and Gets for each variable
// Date 12/7/16             15min       By Daniel Faubel      Action: gave SpaceObject the action position method to calculate change in position
// Date 12/8/16             15min       By Daniel Faubel      Action: Cleaned up SpaceObject so other Objects like SpaceShip could extend from it
// Date: 12/9/16            60min      By: Daniel Faubel     Action :Set up polygon so each spaceobject could have a shape polygon

// ---------------------------------------------------
import java.util.ArrayList;
import java.awt.Polygon;
import java.awt.geom.Ellipse2D;
import java.awt.Rectangle;
import java.lang.Math;
import java.util.concurrent.TimeUnit;
import java.awt.Polygon;
public class SpaceObject {
    //Declares SpaceObject int values
    private int direction,XPosition, YPosition, mass, size, speed, turn, HP;
    
    private Polygon polygon;
   
    private int[] xarr = { 0, 20, 0 ,-20, 0};  
    private int[] yarr = {50, -30, -10, -30, 50};
    private int[] xarrturn = new int[5];
    private int[] yarrturn = new int[5];
    //Empty SpaceObject constructor
    public SpaceObject(){
        
        this.mass = 10;
        this.size = 10;
        this.direction = 90;
        this.turn = 0;
        this.XPosition = 600;
        this.YPosition = 450;
        this.HP = 1;
        this.size = 25;
        this.speed = 0;
        this.polygon = new Polygon(xarr, yarr, 5);
    }
    //Filled SpaceObject Constructor
    public SpaceObject(int m, int d, int t, int x, int y, int si, int sp, Polygon p, int hp){//, Polygon p){
        this.mass = m;
        this.direction = d;
        this.turn = t;
        this.YPosition = y;
        this.XPosition = x;
        this.size = 25;
        this.speed = sp;
        this.polygon = new Polygon(xarr, yarr, 5);
        this.HP = 1;
    }
    
    //get and set methods for all SpaceObject Variables
    public int getTurn()
    {
        return turn;
    }
    public void setTurn(int t){
        this.turn = t;
    }
    
    public int getMass()
    {
        return mass;
    }
    public void setMass(int val)
    {
        this.mass = val;
    }
    public int getSize()
    {
        return size;
    }
    public void setSize(int val){
        this.size = val;
    }
    public int getDirection(){
        return direction;
    }
    public void setDirection(int val){
        this.direction = val;
    }
    public int getXPosition()// Used to aquire the Space Objects current X Position
    {
        return XPosition;
    }
    public void setXPosition(int val){
        this.XPosition = val;
    }
    public int getYPosition() // Used to aquire the Space Objects current Y Position
    {
        return YPosition;
    }
    public void setYPosition(int val){
       this.YPosition = val;
    }
    public void setSpeed(int val){
        this.speed =val;
    }
    public int getSpeed(){
        return speed;
    } 
    public void SetPosition(){
          //int chagex = static int sin(direction);
          YPosition -= Math.sin(Math.toRadians(direction)) * speed;
          XPosition -= Math.cos(Math.toRadians(direction)) * speed;
    }
    public void turnpolygon(){
        double xtemp, ytemp, length, angle;

       for(int i = 0; i < xarr.length; i++){            
            xtemp = xarr[i];
            ytemp = yarr[i];
            angle = (Math.atan2(ytemp, xtemp));
            angle = Math.toDegrees(angle);
            length = Math.sqrt(Math.pow(xtemp, 2) + Math.pow(ytemp, 2));
            xtemp = length *Math.cos(Math.toRadians(angle+ direction-90));
            ytemp = length *Math.sin(Math.toRadians(angle +direction-90));
            this.xarrturn[i] = (int)(xtemp);
            this.yarrturn[i]  = (int)(ytemp );  

       }
        
    }
    public void setpolygon(){
        Polygon Ship = new Polygon();
        double xtemp, ytemp;
        int x, y;
        for (int i = 0; i < 5; i++) {
            xtemp = getXPosition();
            ytemp = getYPosition();
            x = (int)(xtemp - (this.xarrturn[i]));
            y =(int)(ytemp - (this.yarrturn[i])) ;        
            Ship.addPoint(x , y );
            }
        this.polygon = Ship;
    }
    
    public Polygon getpolygon(){
        return this.polygon;
    }
    // @Override
    public void startProjectile() {
        XPosition = ((int)(XPosition- (Math.sin(Math.toRadians(direction)) * (2.5 * size))));
        YPosition = ((int)(YPosition -(Math.sin(Math.toRadians(direction)) * (2.5 * size))));
    }

      public void setHP(int val){
        this.HP = val;
    }
    public int getHP(){
        return HP;
    }
    //Method responds to a collision with another SpaceObject
    public void HitSpaceObject(SpaceObject spaceobj){
        
        this.HP = -1; 
    }
    
    //Method of actions that SpaceObject can preform
    public  void Actions(){
        SetPosition();
        direction += turn*5;
        if(direction < 0)
            direction+=360;
        else if(direction > 360)
            direction -=360; 
    }
    public void pause(){
                    try{
                        Thread.sleep(10);
                    }
                    catch (InterruptedException err){
                //e.printStackTrace();
            }
    }
}