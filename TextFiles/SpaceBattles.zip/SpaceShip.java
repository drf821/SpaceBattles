// File name: SpaceShip

// Written by: Daniel Faubel
 
// Description: Has everything a Spaceship needs to run
//
//              
// Challenges: 
//
// Time Spent: 15 min

// Revision History:
// Date: 11/22/16      	15 min	By: Daniel Faubel     Action: Created The GUI Interface for StartMenu
// Date: 12/6/16        30 min  By: Daniel Faubel     Action: Added sets and gets for all SpaceShip variables
// Date: 12/7/16        15 min  By  Daniel Faubel     Action: asded what SpaceShip needed for it's action method
// Date: 12/9/16        60min   By: Daniel Faubel     Action :cleaned up the constructor in order to sync with the rest of the program

// ---------------------------------------------------
import java.awt.event.*;
import java.awt.Polygon;
public class SpaceShip extends SpaceObject{
    private  int ForwardForce, BackwardForce;
    
    //Empty SpaceShip Constructor
    public SpaceShip(){
        super();
        this.ForwardForce = 0;
        this.BackwardForce = 0;
    }
    //Spaceship Constructor
    public SpaceShip(int m, // Mass
                     int d, // Direction (degrees clockwise from the 3:00 position)
                     int t, int x, int y, int si, int sp, Polygon p, int hp, int f, int b){ 
        super(m, d, t, x, y, si, sp, p, hp); 
        this.ForwardForce = f;
        this.BackwardForce = b;
    }
    //Set and get methods for Spaceship Variables
    public void setForwardForce(int val){
        this.ForwardForce = val;
    }
    public int getForwardForce(){
        return ForwardForce;
    }
    public void setBackwardForce(int val){
        this.BackwardForce = val;
    }
    public int getBackwardForce(){
        return BackwardForce;
    }   
    //An Actions Method for SpaceShip
    
    @Override
    public void Actions(){
        super.Actions();
//        super.setSpeed((super.getSpeed()+ (ForwardForce-BackwardForce))/3);
//        //System.out.println("Speed equals: " + this.getSpeed());
//        BackwardForce = super.getSpeed();     
    }
    //A method for SpaceShip to fire a shot
    public void FireShot(){
        int d, x, y;
        d = getDirection();
        x = getXPosition();
        y = getYPosition();
        
        SpaceObject shot = new Shot(d, x, y);
        shot.setpolygon();
        shot.startProjectile();
        Space.addSpaceObject(shot); 
    }   
}