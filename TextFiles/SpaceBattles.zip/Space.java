// File name: Space

// Written by: Daniel Faubel
// Description: is the panel that all SpaceObjects are placed on
//              
// Challenges: 
//
// Time Spent: 15 min
// Revision History:
// Date: 11/29/16           15min	By: Daniel Faubel     Action: added paintComponent, Set, and CheckPositions methods
// Date: 12/8/16            60min       By: Daniel Faubel     Action: added Set Method to handle each set for SpaceObjects
// Date: 12/9/16            240min      By: Daniel Faubel     Action :added basic threading to operate the entire program. Made Space 
//                                                            both a KeyListener and a Runnable by implementing. Space will initiate all
//                                                            SpaceObjects and watch while game is going.
// ---------------------------------------------------
import javax.swing.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.util.*;
import java.awt.Polygon;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Space extends JPanel implements Runnable, KeyListener {

    public static ArrayList<SpaceObject> spaceList;// = new ArrayList<SpaceObject>();
    UserSpaceShip userShip;
    SpaceObject[] spaceobject;
    private int[] xarr2 = {0, 2, 0, -2, 0};
    private int[] yarr2 = {-5, 3, 1, 3, -5};
    private int[] xarr3, yarr3;
    Random rand = new Random();
    Polygon poly = new Polygon(xarr2, yarr2, 5);

    public Space() {
        spaceobject = new SpaceObject[6];
        spaceList = new ArrayList<SpaceObject>();
        spaceList.clear();
        userShip = new UserSpaceShip(5, 90, 0, 400, 300, 10, 0, new Polygon(), 50, 0, 5);
        spaceList.add(userShip);
        for (int i = 0; i < spaceobject.length; i++) {
            spaceobject[i] = new SpaceObject(5, 180, 0, (rand.nextInt(900) - 100), (rand.nextInt(600) - 100), 50, 0, poly, 5);
            spaceList.add(spaceobject[i]);
        }
        this.start();

    }

    public void start() {
        setFocusable(true);
        this.addKeyListener(this);

        Thread thread = new Thread(this);
        thread.start();

    }

    //paintComponent method paints the Space Background and objects
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        this.setBackground(Color.GRAY);

        int xtemp, ytemp, sizetemp;
        g.setColor(Color.BLACK);

        //Displays each SpaceObject from spaceList       
        for (int x = 0; x < (spaceList.size()); x++) {
            spaceList.get(x).turnpolygon();
            spaceList.get(x).setpolygon();
            g2d.fillPolygon(spaceList.get(x).getpolygon());
        }

    }

    //Checks each SpaceObjects position in spaceList to check for collisions
    @Override
    public void run() {
        while (true) {
            for (int x = 0; x < spaceList.size(); x++) {
                spaceList.get(x).Actions();
            }
            CheckPositions();
            for (int k = 1; k < spaceList.size(); k++) { //skips checking usership
                if (spaceList.get(k).getHP() < 0) {
                    spaceList.remove(k);
                }
                break;
            }
            repaint();
            pause();
        }
    }

    public void CheckPositions() {
        int start = 0;
        double x, y, isize, jsize;
        for (int i = start; i < spaceList.size() - 1; i++) {
            for (int j = i + 1; j < spaceList.size(); j++) {
                x = ((spaceList.get(i).getXPosition()) - (spaceList.get(j).getXPosition()));
                y = ((spaceList.get(i).getYPosition()) - (spaceList.get(j).getYPosition()));
                isize = spaceList.get(i).getSize();
                jsize = spaceList.get(j).getSize();
                if ((Math.abs(x) + Math.abs(y)) / 2 < (isize + jsize)) {
                    spaceList.get(i).HitSpaceObject(spaceList.get(j));
                    spaceList.get(j).HitSpaceObject(spaceList.get(i));
                    if (i != 0) {
                        spaceList.remove(i);
                    }
                    if (j < spaceList.size()) {
                        spaceList.remove(j);
                    }
                }
            }
        }
    }
    int keyCode;

    @Override
    public void keyPressed(KeyEvent e) {
        keyCode = e.getKeyCode();
        switch (keyCode) {
            case KeyEvent.VK_UP:
                // handle up                     
                userShip.onForwardForce();
                break;
            case KeyEvent.VK_DOWN:
                // handle down 
                userShip.onBackwardForce();

                //    System.out.println("Down Arrow Key Pressed");
                //  pause();
                break;
            case KeyEvent.VK_LEFT:
                // handle left
                userShip.onLeftTurn();
                //    System.out.println("Left Arrow Key Pressed");
                // pause();

                break;
            case KeyEvent.VK_RIGHT:
                // handle right
                userShip.onRightTurn();
                //    System.out.println("Right Arrow Key Pressed");
                // pause();
                break;
            case KeyEvent.VK_SPACE:
                userShip.FireShot();
                pause();
                break;
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        keyCode = e.getKeyCode();
        switch (keyCode) {
            case KeyEvent.VK_UP:
                // handle up                     
                userShip.offForwardForce();
                //     System.out.println("UP Arrow Key Released");
                //   pause();
                break;
            case KeyEvent.VK_DOWN:
                // handle down 
                userShip.offBackwardForce();
                //   pause();
                //    System.out.println("DOWN Arrow Key Released");
                break;
            case KeyEvent.VK_LEFT:
                // handle left
                userShip.offLeftTurn();
                //    System.out.println("LEFT Arrow Key Released");
                break;
            case KeyEvent.VK_RIGHT:
                // handle right
                userShip.offRightTurn();
                // System.out.println("RIGHT Arrow Key Released");
                // pause();
                break;
        }
        //pause();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    public void pause() {
        try {
            Thread.sleep(50);
        } catch (InterruptedException err) {
            //e.printStackTrace();
        }
    }

    public static void addSpaceObject(SpaceObject spobj) {
        if (!spaceList.add(spobj)) {
            System.out.println("foo");
        }
    }
}
