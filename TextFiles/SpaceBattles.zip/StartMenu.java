// File name: StartMenu

// Written by: Daniel Faubel
 
// Description: Will show a StartMenu where the user can select the level and difficulty then start the game. Will also have an exit button
//              to close the page, and a Rules button to create a messagebox with the games rules and instructions.                
//              
// Challenges: 
//
// Time Spent: 3 

// Revision History:
// Date: 11/17/16           30min	By: Daniel Faubel     Action: Created The GUI Interface for StartMenu
// Date: 12/1/16            30min       By: Daniel Faubel     Action: Setup The ButtonHandler to perform action events for each of the 3
//                                                            buttons, and added 3 different methods to be used if the connected button
//                                                            is selected. I used methods because they may be called at multiple locations 
// Date 12/5/16             60min       By: Daniel Faubel     Action: add a listener to handle each button click and call its mehod
// Date 12/6/16                         By: Daniel Faubel     Action: 
// ---------------------------------------------------

import com.sun.prism.paint.Color;
import javax.swing.*;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.Scanner;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class StartMenu extends JFrame {
    private  String[] Levels = {"Level 1"};
    private  String[]  Difficulties = {"Easy"};
    
    public static final int ScreenX = 1200;
    public static final int ScreenY = 900;
    private Scanner input;
   
    private Space Screen;
    
    private JLabel              Levellbl, Difficultylbl;
    private JButton             Instructionbtn, Startbtn, Exitbtn;
    private JComboBox<String>   Levelcmbx;
    private       JComboBox<String>   Difficultycmbx;
    private final JPanel        p1, p2, p3;
    private       Color               c ;
    private final ButtonHandler btnhandler;
   
    public StartMenu(){
        super("Space Battles Start Menu");

        c              = new Color(212, 212, 212, 212);
        Levellbl       = new JLabel("Level: ");
        Difficultylbl  = new JLabel("Difficulty");
        Instructionbtn = new JButton("Instructions");
        Startbtn       = new JButton("Start");
        Exitbtn        = new JButton("Exit");
        btnhandler     = new ButtonHandler();
        
        Startbtn.addActionListener(btnhandler);
        Exitbtn.addActionListener(btnhandler);
        Instructionbtn.addActionListener(btnhandler);
        
        
        Levelcmbx = new JComboBox<String> (Levels);
        Difficultycmbx = new JComboBox<String> (Difficulties);
        
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        
        setLayout(new BorderLayout(150, 150));
        p2.setLayout(new GridLayout(1, 4));
        p3.setLayout(new BorderLayout(50,50));
        
        p2.add(Levellbl);
        p2.add(Levelcmbx);
        p2.add(Difficultylbl);
        p2.add(Difficultycmbx);
        
        p3.add(Instructionbtn, BorderLayout.WEST);
        p3.add(Startbtn, BorderLayout.CENTER);
        p3.add(Exitbtn, BorderLayout.EAST);
        
        add(p1, BorderLayout.NORTH);
        add(p2, BorderLayout.CENTER);
        add(p3, BorderLayout.SOUTH);
    }   
        
    private class ButtonHandler implements ActionListener
    {
        @Override            
        public void actionPerformed(ActionEvent event)
        {
            if(event.getSource() == Startbtn)
                StartGame();
            else if(event.getSource() == Exitbtn )
                 ExitStartMenu();
            else if(event.getSource() == Instructionbtn)
                ShowInstructions();
        }
    } 
    @Override
    public void paint(Graphics g){
        super.paint(g);
        g.setFont(new Font("Courier", Font.BOLD+Font.ITALIC, 64));
        g.drawString("Space Battles", 75, 150);
    }
    public void StartGame(){
        SpaceBackground SpaceMap = new SpaceBackground();
        Screen = new Space();
        SpaceMap.setSize(ScreenX, ScreenY);
        SpaceMap.setLocationRelativeTo(null);
        SpaceMap.setVisible(true);
        SpaceMap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        SpaceMap.add(Screen);
    }
    public  void ShowInstructions()
    {
        Path myPath = Paths.get("SpaceBattlesInstructions.txt");
    }
    public void ExitStartMenu()
    {
        System.exit(0);
    }
}
    

