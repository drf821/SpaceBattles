/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author danie
 */
import java.awt.Polygon;
public class SpaceProjectile extends SpaceObject {
    private int Speed;
    
    //A filled SpaceProjectile Constructor
    public SpaceProjectile(int m, int d, int t, int x, int y, int si,  int sp, Polygon p, int hp){
        super(m, d, t, x, y, si, sp, p, hp);
    }
    //A method when a SpaceProjectile leaves the screen
    public void startProjectile(){
    
    }
    public void LeaveScreen(){
        //When SpaceProjectile has left the screen
    }
}
