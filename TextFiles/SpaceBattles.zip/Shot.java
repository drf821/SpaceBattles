/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author danie
 */
import java.awt.Polygon;

public class Shot extends SpaceProjectile {

    private int[] xarr = {4, 0, -4, -4, 4};
    private int[] yarr = {4, 6, 4, -4, -4};
    private int[] xarrturn1 = new int[5];
    private int[] yarrturn1 = new int[5];

    private Polygon polygon1;

    public Shot(int m, int d, int t, int x, int y, int si, int sp, Polygon p, int hp) {
        super(m, d, t, x, y, si, sp, p, hp);
    }

    public Shot(int d, int x, int y) {
        super(1, d, 0, x, y, 10, 20, new Polygon(), 5);
    }

    public Shot() {
        super(1, 0, 0, 0, 0, 5, 20, new Polygon(), 0);
    }

    public Polygon Polygonshot() {
        return this.Polygonshot();
    }

     @Override
    public void startProjectile() {
        super.setXPosition((int) (super.getXPosition() - (Math.cos(Math.toRadians(super.getDirection())) * (3 * super.getSize()))));
        super.setYPosition((int) (super.getYPosition() - (Math.sin(Math.toRadians(super.getDirection())) * (3 * super.getSize()))));
        super.setDirection(super.getDirection());

    }

    public void LeaveScreen() {
        //When SpaceProjectile has left the screen
    }

    @Override
    public void turnpolygon() {
        double xtemp, ytemp, length, angle;

        for (int i = 0; i < xarr.length; i++) {
            xtemp = this.xarr[i];
            ytemp = this.yarr[i];
            angle = (Math.atan2(ytemp, xtemp));
            angle = Math.toDegrees(angle);
            length = Math.sqrt(Math.pow(xtemp, 2) + Math.pow(ytemp, 2));
            xtemp = length * Math.cos(Math.toRadians(angle + super.getDirection() - 90));
            ytemp = length * Math.sin(Math.toRadians(angle + super.getDirection() - 90));
            xarrturn1[i] = (int) (xtemp);
            yarrturn1[i] = (int) (ytemp);

        }
    }

    @Override
    // Create a square shaped polygon
    public void setpolygon() {
        Polygon currentShotImage = new Polygon();
        double xtemp, ytemp;
        int x, y;
        for (int i = 0; i < 5; i++) {
            xtemp = getXPosition();
            ytemp = getYPosition();
            x = (int) (xtemp - (this.xarrturn1[i]));
            y = (int) (ytemp - (this.yarrturn1[i]));
            currentShotImage.addPoint(x, y);
        }
        this.polygon1 = currentShotImage;
    }

    public Polygon getpolygon() {
        return this.polygon1;
    }
}
