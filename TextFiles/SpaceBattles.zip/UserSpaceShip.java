// File name: SpaceShip

// Written by: Daniel Faubel
 
// Description: Has everything a Spaceship needs to run
//
//              
// Challenges: 
//
// Time Spent: 15 min

// Revision History:
// Date: 12/6/16      	30 min      By Daniel Faubel        Action: Added a key listenr that will listen for up, down, left, right, and 
//                                                          space key presses.
// Date: 12/9/16            120min      By: Daniel Faubel     Action :Set up methods to be called from the keylistener in the space class

// ---------------------------------------------------
import java.awt.event.*;
import java.awt.event.KeyEvent.*;
import java.awt.event.KeyListener;
import java.awt.Polygon;
public class UserSpaceShip extends SpaceShip {

    public UserSpaceShip(){
        super();
    }
    //Filled UserSpaceShip constructor
    public UserSpaceShip(int m, int d, int t, int x, int y, int si, int sp, Polygon p, int hp,  int f, int b){ //Polygon p,
        super(m, d, t, x, y, si, sp, p, 50 , f, b);//p,
    }
   
    public void onForwardForce(){
        int xtemp, ytemp, angle, force;
        force = -10;
        angle = this.getDirection();
        xtemp = (int)(force*Math.cos(Math.toRadians(angle)));
        ytemp = (int)(force*Math.sin(Math.toRadians(angle)));
        super.setYPosition((getYPosition()+ ytemp));
        super.setXPosition((getXPosition()+ xtemp));
    }
    public void onBackwardForce(){
        int xtemp, ytemp, angle, force;
        force = 10;
        angle = this.getDirection();
        xtemp = (int)(force*Math.cos(Math.toRadians(angle)));
        ytemp = (int)(force*Math.sin(Math.toRadians(angle)));
        super.setYPosition((getYPosition()+ ytemp));
        super.setXPosition((getXPosition()+ xtemp));    }
    public void onRightTurn(){
        //super.setXPosition(getXPosition() +8);
        setTurn(1);
    }
    public void onLeftTurn(){
        //super.setXPosition(getXPosition() -8);
        setTurn(-1);
    }
    public void offForwardForce(){
        super.setSpeed(0);    
    }
    
    public void offBackwardForce(){
        super.setSpeed(0);   
    }
    public void offRightTurn(){
        setTurn(0);
    }
    public void offLeftTurn(){
        setTurn(0);
    }
    @Override
    public void Actions(){
        super.Actions();
    }
}    